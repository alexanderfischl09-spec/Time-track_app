# Keine speziellen Regeln notwendig, Minify ist deaktiviert.
