package com.timetracker.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.timetracker.app.data.AppDatabase
import com.timetracker.app.data.Repository
import com.timetracker.app.data.TimeEntry
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = Repository(AppDatabase.getInstance(application))

    val allEntries = repository.allEntries.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )
    val runningEntry = repository.runningEntry.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), null
    )
    val allNames = repository.allNames.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )
    val allStamps = repository.allStamps.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )
    val allPointEntries = repository.allPointEntries.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )
    val totalScore = repository.totalScore.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), 0
    )
    val allActivityNames = repository.allActivityNames.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    fun startEntry(name: String) {
        viewModelScope.launch { repository.startEntry(name) }
    }

    fun endEntry(entry: TimeEntry) {
        viewModelScope.launch { repository.endEntry(entry) }
    }

    fun updateEntry(entry: TimeEntry) {
        viewModelScope.launch { repository.updateEntry(entry) }
    }

    fun deleteEntry(id: Long) {
        viewModelScope.launch { repository.deleteEntry(id) }
    }

    fun addStamp() {
        viewModelScope.launch { repository.addStamp() }
    }

    fun deleteStamp(id: Long) {
        viewModelScope.launch { repository.deleteStamp(id) }
    }

    fun addPointEntry(activity: String, points: Int) {
        viewModelScope.launch { repository.addPointEntry(activity, points) }
    }

    fun deletePointEntry(id: Long) {
        viewModelScope.launch { repository.deletePointEntry(id) }
    }

    fun deleteAllData() {
        viewModelScope.launch { repository.deleteAllData() }
    }
}
