package com.timetracker.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.timetracker.app.ui.screens.EditEntryScreen
import com.timetracker.app.ui.screens.HistoryScreen
import com.timetracker.app.ui.screens.HomeScreen
import com.timetracker.app.ui.screens.PointsScreen
import com.timetracker.app.ui.theme.TimeTrackerTheme

class MainActivity : ComponentActivity() {
    private val viewModel: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TimeTrackerTheme {
                TimeTrackerApp(viewModel)
            }
        }
    }
}

@Composable
fun TimeTrackerApp(viewModel: AppViewModel) {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            HomeScreen(
                viewModel = viewModel,
                onOpenHistory = { navController.navigate("history") },
                onOpenPoints = { navController.navigate("points") }
            )
        }
        composable("points") {
            PointsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable("history") {
            HistoryScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onEditEntry = { id -> navController.navigate("edit/$id") }
            )
        }
        composable("edit/{entryId}") { backStackEntry ->
            val entryId = backStackEntry.arguments?.getString("entryId")?.toLongOrNull() ?: -1L
            EditEntryScreen(
                viewModel = viewModel,
                entryId = entryId,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
