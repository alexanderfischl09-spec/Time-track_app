package com.timetracker.app.data

class Repository(private val db: AppDatabase) {
    val allEntries = db.timeEntryDao().getAll()
    val runningEntry = db.timeEntryDao().getRunning()
    val allNames = db.timeEntryDao().getAllNames()
    val allStamps = db.stampDao().getAll()

    suspend fun startEntry(name: String) {
        db.timeEntryDao().insert(TimeEntry(name = name, startMillis = System.currentTimeMillis()))
    }

    suspend fun endEntry(entry: TimeEntry) {
        db.timeEntryDao().update(entry.copy(endMillis = System.currentTimeMillis()))
    }

    suspend fun updateEntry(entry: TimeEntry) {
        db.timeEntryDao().update(entry)
    }

    suspend fun deleteEntry(id: Long) {
        db.timeEntryDao().deleteById(id)
    }

    suspend fun addStamp() {
        db.stampDao().insert(Stamp(timestampMillis = System.currentTimeMillis()))
    }

    suspend fun deleteStamp(id: Long) {
        db.stampDao().deleteById(id)
    }

    suspend fun deleteAllData() {
        db.timeEntryDao().deleteAll()
        db.stampDao().deleteAll()
    }
}
