package com.timetracker.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TimeEntryDao {
    @Query("SELECT * FROM time_entries ORDER BY startMillis DESC")
    fun getAll(): Flow<List<TimeEntry>>

    @Query("SELECT * FROM time_entries WHERE endMillis IS NULL LIMIT 1")
    fun getRunning(): Flow<TimeEntry?>

    @Query("SELECT DISTINCT name FROM time_entries ORDER BY name ASC")
    fun getAllNames(): Flow<List<String>>

    @Insert
    suspend fun insert(entry: TimeEntry): Long

    @Update
    suspend fun update(entry: TimeEntry)

    @Query("DELETE FROM time_entries WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM time_entries")
    suspend fun deleteAll()
}

@Dao
interface StampDao {
    @Query("SELECT * FROM stamps ORDER BY timestampMillis DESC")
    fun getAll(): Flow<List<Stamp>>

    @Insert
    suspend fun insert(stamp: Stamp): Long

    @Query("DELETE FROM stamps WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM stamps")
    suspend fun deleteAll()
}
