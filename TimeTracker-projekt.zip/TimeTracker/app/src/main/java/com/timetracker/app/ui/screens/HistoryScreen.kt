package com.timetracker.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.timetracker.app.AppViewModel
import com.timetracker.app.data.TimeEntry
import com.timetracker.app.data.TimeUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    viewModel: AppViewModel,
    onBack: () -> Unit,
    onEditEntry: (Long) -> Unit
) {
    val entries by viewModel.allEntries.collectAsState()
    val finished = entries.filter { it.endMillis != null }
    val grouped = finished.groupBy { TimeUtils.dayKey(it.startMillis) }
        .toSortedMap(compareByDescending { it })

    var entryToDelete by remember { mutableStateOf<TimeEntry?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Verlauf") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Zurück")
                    }
                }
            )
        }
    ) { padding ->
        if (grouped.isEmpty()) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Noch keine abgeschlossenen Zeiterfassungen", color = MaterialTheme.colorScheme.outline)
            }
        } else {
            LazyColumn(modifier = Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
                grouped.forEach { (day, dayEntries) ->
                    item {
                        val totalMillis = dayEntries.sumOf { (it.endMillis ?: 0) - it.startMillis }
                        Column(Modifier.padding(top = 12.dp, bottom = 4.dp)) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(day, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(
                                    "Gesamt: ${TimeUtils.formatDurationShort(totalMillis)}",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Divider(Modifier.padding(top = 4.dp))
                        }
                    }
                    items(dayEntries.sortedByDescending { it.startMillis }, key = { it.id }) { entry ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                                .clickable { onEditEntry(entry.id) }
                        ) {
                            Row(
                                Modifier.padding(12.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(entry.name, fontWeight = FontWeight.Bold)
                                    Text(
                                        "${TimeUtils.formatTime(entry.startMillis)} – ${TimeUtils.formatTime(entry.endMillis!!)}",
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    Text(
                                        TimeUtils.formatDuration(entry.endMillis - entry.startMillis),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                                IconButton(onClick = { entryToDelete = entry }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Löschen")
                                }
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }

    entryToDelete?.let { entry ->
        AlertDialog(
            onDismissRequest = { entryToDelete = null },
            title = { Text("Eintrag löschen?") },
            text = { Text("Möchtest du \"${entry.name}\" wirklich löschen?") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteEntry(entry.id)
                    entryToDelete = null
                }) { Text("LÖSCHEN") }
            },
            dismissButton = {
                TextButton(onClick = { entryToDelete = null }) { Text("ABBRECHEN") }
            }
        )
    }
}
