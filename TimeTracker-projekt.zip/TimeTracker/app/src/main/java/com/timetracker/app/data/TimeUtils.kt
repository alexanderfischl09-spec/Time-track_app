package com.timetracker.app.data

import java.text.SimpleDateFormat
import java.util.*

object TimeUtils {
    private val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY)
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.GERMANY)
    private val dateTimeFormat = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.GERMANY)

    fun formatDate(millis: Long): String = dateFormat.format(Date(millis))
    fun formatTime(millis: Long): String = timeFormat.format(Date(millis))
    fun formatDateTime(millis: Long): String = dateTimeFormat.format(Date(millis))

    fun dayKey(millis: Long): String = dateFormat.format(Date(millis))

    fun formatDuration(durationMillis: Long): String {
        val totalSeconds = durationMillis / 1000
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        val s = totalSeconds % 60
        return buildString {
            if (h > 0) append("${h}h ")
            append("${m}min ")
            append("${s}s")
        }
    }

    fun formatDurationShort(durationMillis: Long): String {
        val totalSeconds = durationMillis / 1000
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        return if (h > 0) "${h}h ${m}min" else "${m}min"
    }
}
