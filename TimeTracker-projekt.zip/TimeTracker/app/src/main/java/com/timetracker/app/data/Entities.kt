package com.timetracker.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "time_entries")
data class TimeEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val startMillis: Long,
    val endMillis: Long? = null
)

@Entity(tableName = "stamps")
data class Stamp(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestampMillis: Long
)
