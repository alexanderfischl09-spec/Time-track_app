package com.timetracker.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.timetracker.app.AppViewModel
import com.timetracker.app.data.PointEntry
import com.timetracker.app.data.TimeUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PointsScreen(viewModel: AppViewModel, onBack: () -> Unit) {
    val entries by viewModel.allPointEntries.collectAsState()
    val totalScore by viewModel.totalScore.collectAsState()
    val activityNames by viewModel.allActivityNames.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var entryToDelete by remember { mutableStateOf<PointEntry?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Punkte") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Zurück")
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp).fillMaxSize()) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    Modifier.padding(20.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("PUNKTESTAND", style = MaterialTheme.typography.labelLarge)
                    Text(
                        (if (totalScore > 0) "+$totalScore" else "$totalScore"),
                        fontSize = 48.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (totalScore >= 0) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            Button(
                onClick = { showAddDialog = true },
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Text("+ AKTIVITÄT EINTRAGEN", fontSize = 16.sp)
            }

            Spacer(Modifier.height(16.dp))
            Text("VERLAUF", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))

            if (entries.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Noch keine Einträge", color = MaterialTheme.colorScheme.outline)
                }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(entries, key = { it.id }) { entry ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable { entryToDelete = entry }
                        ) {
                            Row(
                                Modifier.padding(12.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(entry.activity, fontWeight = FontWeight.Bold)
                                    Text(
                                        TimeUtils.formatDateTime(entry.timestampMillis),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                                Text(
                                    if (entry.points > 0) "+${entry.points}" else "${entry.points}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp,
                                    color = if (entry.points >= 0) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                    item { Spacer(Modifier.height(24.dp)) }
                }
            }
        }
    }

    if (showAddDialog) {
        AddPointEntryDialog(
            existingNames = activityNames,
            onDismiss = { showAddDialog = false },
            onConfirm = { activity, points ->
                viewModel.addPointEntry(activity, points)
                showAddDialog = false
            }
        )
    }

    entryToDelete?.let { entry ->
        AlertDialog(
            onDismissRequest = { entryToDelete = null },
            title = { Text("Eintrag löschen?") },
            text = { Text("\"${entry.activity}\" (${if (entry.points > 0) "+" else ""}${entry.points} Punkte) wirklich löschen?") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deletePointEntry(entry.id)
                    entryToDelete = null
                }) { Text("LÖSCHEN") }
            },
            dismissButton = {
                TextButton(onClick = { entryToDelete = null }) { Text("ABBRECHEN") }
            }
        )
    }
}

@Composable
private fun AddPointEntryDialog(
    existingNames: List<String>,
    onDismiss: () -> Unit,
    onConfirm: (String, Int) -> Unit
) {
    var activity by remember { mutableStateOf("") }
    var selectedPoints by remember { mutableStateOf(1) }
    var isBonus by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Aktivität eintragen") },
        text = {
            Column {
                OutlinedTextField(
                    value = activity,
                    onValueChange = { activity = it },
                    label = { Text("Aktivität") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (existingNames.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("Zuletzt verwendet:", style = MaterialTheme.typography.labelMedium)
                    Column {
                        existingNames.chunked(3).forEach { row ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                row.forEach { n ->
                                    AssistChip(onClick = { activity = n }, label = { Text(n) })
                                }
                            }
                            Spacer(Modifier.height(4.dp))
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = isBonus,
                        onClick = { isBonus = true },
                        label = { Text("BONUS (+)") },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = !isBonus,
                        onClick = { isBonus = false },
                        label = { Text("MALUS (–)") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(Modifier.height(12.dp))
                Text("Punkte: $selectedPoints", style = MaterialTheme.typography.labelMedium)
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    (1..6).forEach { p ->
                        FilterChip(
                            selected = selectedPoints == p,
                            onClick = { selectedPoints = p },
                            label = { Text("$p") }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val finalPoints = if (isBonus) selectedPoints else -selectedPoints
                    if (activity.isNotBlank()) onConfirm(activity.trim(), finalPoints)
                },
                enabled = activity.isNotBlank()
            ) { Text("SPEICHERN") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("ABBRECHEN") }
        }
    )
}
