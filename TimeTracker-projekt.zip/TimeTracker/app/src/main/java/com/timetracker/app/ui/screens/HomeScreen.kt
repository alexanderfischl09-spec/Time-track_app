package com.timetracker.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.timetracker.app.AppViewModel
import com.timetracker.app.data.TimeUtils
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: AppViewModel, onOpenHistory: () -> Unit, onOpenPoints: () -> Unit) {
    val running by viewModel.runningEntry.collectAsState()
    val stamps by viewModel.allStamps.collectAsState()
    val names by viewModel.allNames.collectAsState()
    val totalScore by viewModel.totalScore.collectAsState()

    var showNewEntryDialog by remember { mutableStateOf(false) }
    var showDeleteAllDialog by remember { mutableStateOf(false) }

    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(running) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("TimeTracker", fontWeight = FontWeight.Bold) })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize()
        ) {
            // PUNKTESTAND
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenPoints() }
            ) {
                Row(
                    Modifier.padding(16.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("PUNKTESTAND", fontWeight = FontWeight.Bold)
                    Text(
                        (if (totalScore > 0) "+$totalScore" else "$totalScore"),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (totalScore >= 0) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                    )
                }
            }
            Spacer(Modifier.height(16.dp))

            // ZEITERFASSUNG
            Text("ZEITERFASSUNG", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    if (running == null) {
                        Button(
                            onClick = { showNewEntryDialog = true },
                            modifier = Modifier.fillMaxWidth().height(56.dp)
                        ) {
                            Text("+ NEUE ZEITERFASSUNG", fontSize = 16.sp)
                        }
                    } else {
                        val entry = running!!
                        Text(entry.name.uppercase(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Läuft seit: ${TimeUtils.formatTime(entry.startMillis)}", style = MaterialTheme.typography.bodyLarge)
                        Text(
                            "Dauer: ${TimeUtils.formatDuration(now - entry.startMillis)}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = { viewModel.endEntry(entry) },
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("ENDE", fontSize = 18.sp)
                        }
                    }
                }
            }

            Spacer(Modifier.height(24.dp))

            // ZEITSTEMPEL
            Text("ZEITSTEMPEL", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { viewModel.addStamp() },
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Text("STEMPELN", fontSize = 18.sp)
            }
            Spacer(Modifier.height(8.dp))
            Card(modifier = Modifier.fillMaxWidth().weight(1f)) {
                if (stamps.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Noch keine Stempel", color = MaterialTheme.colorScheme.outline)
                    }
                } else {
                    LazyColumn(Modifier.padding(8.dp)) {
                        items(stamps, key = { it.id }) { stamp ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp, horizontal = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(TimeUtils.formatDateTime(stamp.timestampMillis))
                                IconButton(onClick = { viewModel.deleteStamp(stamp.id) }) {
                                    Text("✕")
                                }
                            }
                            Divider()
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onOpenHistory, modifier = Modifier.weight(1f)) {
                    Text("VERLAUF")
                }
                OutlinedButton(
                    onClick = { showDeleteAllDialog = true },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("ALLE LÖSCHEN")
                }
            }
        }
    }

    if (showNewEntryDialog) {
        NewEntryDialog(
            existingNames = names,
            onDismiss = { showNewEntryDialog = false },
            onConfirm = { name ->
                viewModel.startEntry(name)
                showNewEntryDialog = false
            }
        )
    }

    if (showDeleteAllDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAllDialog = false },
            title = { Text("Alle Daten löschen?") },
            text = { Text("Willst du wirklich alle Zeiterfassungen und Zeitstempel löschen?") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteAllData()
                    showDeleteAllDialog = false
                }) { Text("LÖSCHEN") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAllDialog = false }) { Text("ABBRECHEN") }
            }
        )
    }
}

@Composable
private fun NewEntryDialog(
    existingNames: List<String>,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Neue Zeiterfassung") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (existingNames.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Text("Zuletzt verwendet:", style = MaterialTheme.typography.labelMedium)
                    FlowRowSimple(existingNames) { chosen -> name = chosen }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { if (name.isNotBlank()) onConfirm(name.trim()) },
                enabled = name.isNotBlank()
            ) { Text("BEGINN") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("ABBRECHEN") }
        }
    )
}

@Composable
private fun FlowRowSimple(names: List<String>, onClick: (String) -> Unit) {
    Column {
        names.chunked(3).forEach { rowNames ->
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowNames.forEach { n ->
                    AssistChip(onClick = { onClick(n) }, label = { Text(n) })
                }
            }
            Spacer(Modifier.height(4.dp))
        }
    }
}
