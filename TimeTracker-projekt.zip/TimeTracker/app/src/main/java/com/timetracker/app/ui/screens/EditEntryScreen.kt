package com.timetracker.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.timetracker.app.AppViewModel
import com.timetracker.app.data.TimeUtils
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditEntryScreen(viewModel: AppViewModel, entryId: Long, onBack: () -> Unit) {
    val entries by viewModel.allEntries.collectAsState()
    val entry = entries.find { it.id == entryId }

    if (entry == null) {
        Scaffold(topBar = { TopAppBar(title = { Text("Bearbeiten") }) }) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) { Text("Eintrag nicht gefunden") }
        }
        return
    }

    var name by remember(entry.id) { mutableStateOf(entry.name) }
    var startMillis by remember(entry.id) { mutableStateOf(entry.startMillis) }
    var endMillis by remember(entry.id) { mutableStateOf(entry.endMillis ?: entry.startMillis) }

    var showStartPicker by remember { mutableStateOf(false) }
    var showEndPicker by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Eintrag bearbeiten") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Zurück")
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp).fillMaxSize()) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Name") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(16.dp))

            OutlinedButton(onClick = { showStartPicker = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Beginn: ${TimeUtils.formatDateTime(startMillis)}")
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { showEndPicker = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Ende: ${TimeUtils.formatDateTime(endMillis)}")
            }

            Spacer(Modifier.height(16.dp))
            val duration = (endMillis - startMillis).coerceAtLeast(0)
            Text("Dauer: ${TimeUtils.formatDuration(duration)}", style = MaterialTheme.typography.titleMedium)

            Spacer(Modifier.height(24.dp))
            Button(
                onClick = {
                    viewModel.updateEntry(
                        entry.copy(name = name.trim().ifBlank { entry.name }, startMillis = startMillis, endMillis = endMillis)
                    )
                    onBack()
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                enabled = endMillis >= startMillis
            ) {
                Text("SPEICHERN")
            }
        }
    }

    if (showStartPicker) {
        DateTimePickerDialog(
            initialMillis = startMillis,
            onDismiss = { showStartPicker = false },
            onConfirm = { startMillis = it; showStartPicker = false }
        )
    }
    if (showEndPicker) {
        DateTimePickerDialog(
            initialMillis = endMillis,
            onDismiss = { showEndPicker = false },
            onConfirm = { endMillis = it; showEndPicker = false }
        )
    }
}

@Composable
private fun DateTimePickerDialog(
    initialMillis: Long,
    onDismiss: () -> Unit,
    onConfirm: (Long) -> Unit
) {
    val cal = Calendar.getInstance().apply { timeInMillis = initialMillis }
    var year by remember { mutableStateOf(cal.get(Calendar.YEAR)) }
    var month by remember { mutableStateOf(cal.get(Calendar.MONTH)) }
    var day by remember { mutableStateOf(cal.get(Calendar.DAY_OF_MONTH)) }
    var hour by remember { mutableStateOf(cal.get(Calendar.HOUR_OF_DAY)) }
    var minute by remember { mutableStateOf(cal.get(Calendar.MINUTE)) }
    var second by remember { mutableStateOf(cal.get(Calendar.SECOND)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Datum & Uhrzeit") },
        text = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumberField("Tag", day, 1, 31) { day = it }
                    NumberField("Monat", month + 1, 1, 12) { month = it - 1 }
                    NumberField("Jahr", year, 2000, 2100) { year = it }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumberField("Std", hour, 0, 23) { hour = it }
                    NumberField("Min", minute, 0, 59) { minute = it }
                    NumberField("Sek", second, 0, 59) { second = it }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val newCal = Calendar.getInstance()
                newCal.set(year, month, day, hour, minute, second)
                onConfirm(newCal.timeInMillis)
            }) { Text("ÜBERNEHMEN") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("ABBRECHEN") }
        }
    )
}

@Composable
private fun NumberField(label: String, value: Int, min: Int, max: Int, onChange: (Int) -> Unit) {
    OutlinedTextField(
        value = value.toString(),
        onValueChange = { text ->
            val v = text.toIntOrNull()
            if (v != null && v in min..max) onChange(v)
        },
        label = { Text(label) },
        modifier = Modifier.width(90.dp),
        singleLine = true
    )
}
